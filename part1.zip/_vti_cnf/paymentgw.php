vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Jul 2018 10:02:57 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|arwa-PC\\arwa
vti_modifiedby:SR|arwa-PC\\arwa
vti_timecreated:TR|24 Jul 2018 10:02:57 -0000
vti_cacheddtm:TX|24 Jul 2018 10:02:57 -0000
vti_filesize:IR|73875
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1256
vti_backlinkinfo:VX|
