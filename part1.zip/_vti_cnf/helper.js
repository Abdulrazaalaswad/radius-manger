vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|28 Oct 2016 15:02:48 -0000
vti_extenderversion:SR|6.0.2.5516
vti_cacheddtm:TX|28 Oct 2016 15:02:48 -0000
vti_filesize:IR|2517
vti_backlinkinfo:VX|addmoney_tpl.htm listnases_tpl.htm listsrvhistory_tpl.htm listcardseries_tpl.htm listspecperacnt_tpl.htm selectpaymode_tpl.htm addcredits_tpl.htm editservice_tpl.htm listap_tpl.htm listonlineradius_tpl.htm listrefillcards_tpl.htm listservices_tpl.htm newservice_tpl.htm newuser_tpl.htm revokecard_tpl.htm editmanager_tpl.htm listcmts_tpl.htm listmanagers_tpl.htm listonlinecm_tpl.htm listpools_tpl.htm cardgen_tpl.htm iasselpaymode_tpl.htm confirmaddcredits_tpl.htm confirmpostpaidbilling_tpl.htm listspecperbw_tpl.htm listusergroups_tpl.htm listusers_tpl.htm
