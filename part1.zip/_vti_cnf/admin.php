vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Jul 2018 10:02:57 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|arwa-PC\\arwa
vti_modifiedby:SR|arwa-PC\\arwa
vti_timecreated:TR|24 Jul 2018 10:02:57 -0000
vti_cacheddtm:TX|24 Jul 2018 10:02:57 -0000
vti_filesize:IR|92622
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1256
vti_backlinkinfo:VX|newias_tpl.htm confirmdelcmts_tpl.htm editspecperbw_tpl.htm editusergroup_tpl.htm confirmlogout_tpl.htm confirmmakecards_tpl.htm listias_tpl.htm newpool_tpl.htm confirmdelap_tpl.htm editias_tpl.htm editmanager_tpl.htm edituser_tpl.htm home_tpl3-10-16.htm newcmts_tpl.htm newnas_tpl.htm searchtrafficsummary_tpl.htm cardgen_tpl.htm confirmcancelchangesrv_tpl.htm home_tpl.htm searchinvoices_tpl.htm adminmain_tpl4-10-16.htm confirmaddcredits_tpl.htm confirmdelmanager_tpl.htm confirmpostpaidbilling_tpl.htm editnas_tpl.htm listspecperbw_tpl.htm listusers_tpl.htm newap_tpl.htm adminlogin_tpl5-10-16.htm confirmdelusergroup_tpl.htm editservice_tpl.htm listap_tpl.htm searchcts_tpl.htm searchusers_tpl.htm adminmain_tpl.htm bulksms_tpl.htm editpool_tpl.htm editspecperacnt_tpl.htm listcmts_tpl.htm listmanagers_tpl.htm listpools_tpl.htm newmanager_tpl.htm newspecperbw_tpl.htm newusergroup_tpl.htm trafficsummary_tpl.htm confirmbatchbilling_tpl.htm confirmdelservice_tpl.htm editcmts_tpl.htm listnases_tpl.htm postpaidbilling_tpl.htm adminlogin_tpl3-10-16.htm changesrvadm_tpl.htm batchbilling_tpl.htm confirmdelias_tpl.htm listonlineradius_tpl.htm listservices_tpl.htm newservice_tpl.htm trafficreport_tpl.htm listonlinecm_tpl.htm searchrefillcards_tpl.htm adminlogout_tpl.htm bulkmail_tpl.htm checkrefillcard_tpl.htm confirmdeluser_tpl.htm creditsadded_tpl.htm searchpostauth_tpl.htm adminlogin_tpl.htm confirmdelnas_tpl.htm editinvoice_tpl.htm listusergroups_tpl.htm printinvoices_tpl.htm searchtraffic_tpl.htm addcredits_tpl.htm adminmain_tpl3-10-16.htm index_tpl.htm listrefillcards_tpl.htm newuser_tpl.htm revokecard_tpl.htm addmoney_tpl.htm confirmdelpool_tpl.htm editap_tpl.htm editsettings_tpl.htm postpaidinvcompleted_tpl.htm listcardseries_tpl.htm listinvoices_tpl.htm listspecperacnt_tpl.htm newspecperacnt_tpl.htm
