<?php

  // API credentials

  define('_2CO_SID', "vendor_id");
  define('_2CO_SECRET', "secret_word");

  // additional data

  define("_2CO_TEST_MODE", TRUE);
  define("_2CO_SKIP_LANDING", "1");

  // currencies supported by 2Checkout

  $currency_2co = array("ARS",
  		        "AUD",
  		        "BRL",
  		        "CAD",
  		        "CHF",
  		        "DKK",
  		        "EUR",
  		        "GBP",
  		        "HKD",
  		        "INR",
  		        "JPY",
  		        "MXN",
  		        "NOK",
  		        "NZD",
  		        "ZAR",
  		        "SEK",
  		        "USD"
   		       );
?>
